# Architecture

DIKWP SemChain OS uses a four-layer design:

1. **Semantic Object Layer**: Every claim/action/event is registered as C=(D,I,K,W,P,R).
2. **Ledger Layer**: Blocks are appended to a hash chain and evidence refs are summarized by Merkle roots.
3. **Credential Layer**: Blocks can be exported as W3C-VC-like semantic credentials. Production deployments should replace demo HMAC with JOSE/COSE/Linked Data Proofs.
4. **Anchor Layer**: Merkle anchors may be stored in permissioned ledgers, trusted timestamp services, WORM storage, C2PA manifests, or enterprise SIEM.

The prototype is local-first and intentionally contains no network publishing. This prevents accidental data leakage and keeps deployment boundaries explicit.
