# Roadmap

- v0.1: Local-first hash-chain semantic ledger.
- v0.2: REST API and multi-tenant workspace.
- v0.3: W3C VC signing adapter.
- v0.4: Hyperledger Fabric anchor adapter.
- v0.5: C2PA manifest adapter for generated content provenance.
- v0.6: AICAP-CN hardware audit integration.
- v0.7: DID-based organization identity and role delegation.
- v1.0: Production governance package with access control, timestamping and retention controls.
