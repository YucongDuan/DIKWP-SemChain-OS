# Release v0.1.0 Draft

DIKWP SemChain OS v0.1.0 is the first local-first prototype of a DIKWP semantic blockchain system.

Highlights:

- DIKWP semantic block format
- hash-chain ledger
- Merkle evidence anchor
- VC-like semantic credential export
- demo claims
- static boundary audit
- tests and docs

Boundary: this release does not publish to a network, issue tokens, or create production credentials.
