# Open Source Launch Plan

1. Publish as `dikwp-semchain-os`.
2. Pin README with the phrase: "semantic blockchain without token speculation".
3. Create demo GIF showing claim -> DIKWP block -> hash chain -> VC-like export.
4. Cross-link to AnswerGraph, IntentGuard, MemoryLedger, SemanticEnergy, ProofLedger, AgentTrace and AICAP-CN.
5. Invite contributors for Fabric adapter, VC signing adapter, C2PA manifest adapter, and SIEM connector.
6. Release v0.1 as local-first prototype, v0.2 as API server, v0.3 as permissioned-ledger adapter.
