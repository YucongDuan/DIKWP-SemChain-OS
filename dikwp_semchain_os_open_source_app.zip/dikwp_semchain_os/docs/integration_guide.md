# Integration Guide

## With ProofLedger OS
Export claim cards into SemChain blocks. Use ProofLedger alignment score as an evidence field.

## With AgentTrace OS
Export each agent event as a SemChain block. Use the chain tip as replay bundle root.

## With IntentGuard OS
Store blocked/reviewed/allowed decisions as authorization semantic blocks.

## With AICAP-CN
Store DeviceIdentity, CapabilityManifest, CommandProposal, AuthorizationGrant and AuditEvent as semantic blocks.

## With Verifiable Credentials
Use `verifiable_semantic_credentials.json` as a prototype shape. Replace HMAC proof with production VC security mechanisms.

## With Permissioned Blockchain
Use `merkle_anchor.json` as the transaction payload. Keep full semantic blocks in governed storage; write only roots and metadata on-chain when privacy requires minimization.
