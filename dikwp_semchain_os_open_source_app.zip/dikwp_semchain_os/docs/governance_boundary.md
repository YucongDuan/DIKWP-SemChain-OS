# Governance Boundary

Allowed:

- Semantic evidence ledger
- AI output provenance
- Agent action audit
- RAG claim-source alignment anchoring
- Human-reviewed hardware command proposals
- Legal and educational evidence custody

Not allowed:

- Token speculation or deceptive fundraising
- Forged credentials
- Publishing secrets to immutable ledgers
- High-impact automated enforcement
- Anonymous laundering of responsibility
- Replacing legal, medical, judicial or financial professionals

Key rule: **immutability must not become irreversible harm**. Sensitive records require minimization, redaction, access control, and off-chain retention policy.
