# Source Synthesis

DIKWP SemChain OS combines:

- DIKWP as D/I/K/W/P semantic hierarchy.
- Energy-information view: information handling has physical and organizational cost.
- Intent view: semantic records require purpose, constraints, time and feedback.
- Mesh runtime view: evidence, residual, reliability, kill/recovery and action boundary must be explicit.
- Blockchain/provenance view: append-only proofs are useful only when tied to semantic accountability.

The result is a semantic evidence ledger, not a cryptocurrency product.
