# DIKWP Model Mapping

- **D / Data**: raw claim, source excerpt, timestamp, actor, device, model, document, event.
- **I / Information**: relations, scope, source type, subject ID, semantic type, evidence count.
- **K / Knowledge**: rules, standards, mechanisms, domain theory, policy references.
- **W / Wisdom**: risk, legal/ethical boundary, human review requirement, safety edge.
- **P / Purpose**: local intent contract, allowed future use, time scope, feedback condition.
- **R / Reliability**: Solid/Supported/Provisional/Borrowed/Hollow/Blocked, residual, kill condition.

SemChain's differentiator is that it does not store only bytes. It stores semantic accountability.
