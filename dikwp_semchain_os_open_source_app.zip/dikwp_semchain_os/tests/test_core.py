import json
from pathlib import Path
from dikwp_semchain.ledger import SemanticLedger, verify_blocks
from dikwp_semchain.vc import export_semantic_credentials


def sample_items():
    return [{
        "subject_id": "x",
        "claim": "A supported semantic claim.",
        "semantic_type": "ai_claim",
        "purpose": "unit test",
        "evidence": [{"source_id": "s", "text": "source supports claim"}],
        "reliability": "Supported"
    }]


def test_append_and_verify():
    ledger = SemanticLedger()
    ledger.append_many(sample_items())
    blocks = [b.to_dict() for b in ledger.blocks]
    report = verify_blocks(blocks)
    assert report["pass"] is True
    assert report["block_count"] == 1


def test_tamper_detection():
    ledger = SemanticLedger()
    ledger.append_many(sample_items())
    blocks = [b.to_dict() for b in ledger.blocks]
    blocks[0]["claim"] = "tampered"
    report = verify_blocks(blocks)
    assert report["pass"] is False
    assert report["finding_count"] >= 1


def test_vc_export_shape():
    ledger = SemanticLedger()
    ledger.append_many(sample_items())
    creds = export_semantic_credentials([b.to_dict() for b in ledger.blocks])
    assert creds[0]["type"][0] == "VerifiableCredential"
    assert "proof" in creds[0]
