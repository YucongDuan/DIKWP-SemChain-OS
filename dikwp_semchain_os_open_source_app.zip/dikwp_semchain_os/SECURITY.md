# Security Policy

Report issues privately to maintainers. This project is local-first and contains no network calls by default.
