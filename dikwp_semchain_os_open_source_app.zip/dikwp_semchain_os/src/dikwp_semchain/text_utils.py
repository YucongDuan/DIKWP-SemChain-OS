from __future__ import annotations
import re
from typing import Iterable, List

CERTAINTY_WORDS = ["guarantee", "guaranteed", "100%", "always", "never", "only correct", "必然", "保证", "唯一正确"]
SENSITIVE_WORDS = ["password", "secret", "api key", "token", "credential", "密码", "密钥", "凭据"]


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip().lower())


def split_sentences(text: str) -> List[str]:
    parts = re.split(r"(?<=[。！？.!?])\s+|\n+", text)
    return [p.strip() for p in parts if p.strip()]


def keyword_hits(text: str, words: Iterable[str]) -> List[str]:
    lower = text.lower()
    return [w for w in words if w.lower() in lower]
