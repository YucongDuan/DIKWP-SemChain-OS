from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone
import json
from .canonical import canonical_json, sha256_hex, hmac_sha256_hex
from .merkle import merkle_root
from .models import SemanticBlock
from .semantic import build_dikwp_record, collapse_claims

GENESIS_HASH = "0" * 64


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def block_hash_material(block_without_hash: Dict[str, Any]) -> str:
    clean = dict(block_without_hash)
    clean.pop("block_hash", None)
    clean.pop("signature", None)
    return canonical_json(clean)


class SemanticLedger:
    def __init__(self, secret: str = "dikwp-semchain-local-demo-secret"):
        self.secret = secret
        self.blocks: List[SemanticBlock] = []

    @property
    def previous_hash(self) -> str:
        return self.blocks[-1].block_hash if self.blocks else GENESIS_HASH

    def append(self, item: Dict[str, Any]) -> SemanticBlock:
        dikwp = build_dikwp_record(item).to_dict()
        payload = item.get("payload", {})
        evidence_refs = item.get("evidence", [])
        evidence_hashes = [sha256_hex(canonical_json(e)) for e in evidence_refs]
        mroot = merkle_root(evidence_hashes + [sha256_hex(item.get("claim", ""))])
        base = {
            "index": len(self.blocks),
            "timestamp_utc": _now(),
            "subject_id": item.get("subject_id", "unknown"),
            "block_type": item.get("block_type", "semantic_claim"),
            "semantic_type": item.get("semantic_type", "claim"),
            "claim": item.get("claim", ""),
            "evidence_refs": evidence_refs,
            "payload": payload,
            "dikwp": dikwp,
            "previous_hash": self.previous_hash,
            "merkle_root": mroot,
        }
        bh = sha256_hex(block_hash_material(base))
        sig = hmac_sha256_hex(self.secret, bh)
        block = SemanticBlock(block_hash=bh, signature=sig, **base)
        self.blocks.append(block)
        return block

    def append_many(self, items: List[Dict[str, Any]], collapse: bool = True) -> List[SemanticBlock]:
        use_items = collapse_claims(items) if collapse else items
        return [self.append(item) for item in use_items]

    def to_jsonl(self) -> str:
        return "\n".join(json.dumps(b.to_dict(), ensure_ascii=False, sort_keys=True) for b in self.blocks) + "\n"

    def save_jsonl(self, path: str | Path) -> None:
        Path(path).write_text(self.to_jsonl(), encoding="utf-8")

    @staticmethod
    def load_jsonl(path: str | Path) -> List[Dict[str, Any]]:
        p = Path(path)
        return [json.loads(line) for line in p.read_text(encoding="utf-8").splitlines() if line.strip()]


def verify_blocks(blocks: List[Dict[str, Any]], secret: str = "dikwp-semchain-local-demo-secret") -> Dict[str, Any]:
    findings = []
    previous = GENESIS_HASH
    for i, block in enumerate(blocks):
        if block.get("index") != i:
            findings.append({"index": i, "issue": "index_mismatch"})
        if block.get("previous_hash") != previous:
            findings.append({"index": i, "issue": "previous_hash_mismatch"})
        recomputed = sha256_hex(block_hash_material(block))
        if recomputed != block.get("block_hash"):
            findings.append({"index": i, "issue": "block_hash_mismatch", "expected": recomputed, "actual": block.get("block_hash")})
        expected_sig = hmac_sha256_hex(secret, block.get("block_hash", ""))
        if expected_sig != block.get("signature"):
            findings.append({"index": i, "issue": "signature_mismatch"})
        dikwp = block.get("dikwp", {})
        for key in ["D", "I", "K", "W", "P", "R"]:
            if key not in dikwp:
                findings.append({"index": i, "issue": f"missing_dikwp_{key}"})
        previous = block.get("block_hash", "")
    return {
        "pass": len(findings) == 0,
        "block_count": len(blocks),
        "finding_count": len(findings),
        "findings": findings,
        "chain_tip": previous if blocks else GENESIS_HASH,
        "verified_at_utc": _now(),
    }
