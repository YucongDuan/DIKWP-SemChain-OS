from __future__ import annotations
from pathlib import Path
from typing import Dict, Any, List
import ast

FORBIDDEN_IMPORTS = {"requests", "socket", "subprocess", "ftplib", "paramiko", "telnetlib", "asyncssh"}
FORBIDDEN_CALLS = {"eval", "exec", "compile", "open"}
FORBIDDEN_ATTR_CALLS = {("os", "system"), ("os", "popen"), ("pathlib", "Path.unlink")}


def audit_source(path: str | Path) -> Dict[str, Any]:
    root = Path(path)
    findings: List[Dict[str, Any]] = []
    for py in root.rglob("*.py"):
        tree = ast.parse(py.read_text(encoding="utf-8"), filename=str(py))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    base = alias.name.split(".")[0]
                    if base in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(py), "line": node.lineno, "issue": "forbidden_import", "name": alias.name})
            if isinstance(node, ast.ImportFrom):
                base = (node.module or "").split(".")[0]
                if base in FORBIDDEN_IMPORTS:
                    findings.append({"file": str(py), "line": node.lineno, "issue": "forbidden_import_from", "name": node.module})
            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name) and node.func.id in FORBIDDEN_CALLS:
                    # allow read/write in code? We avoid flagging open because pathlib write_text is used by CLI external output. Do not use built-in open in source.
                    findings.append({"file": str(py), "line": node.lineno, "issue": "forbidden_call", "name": node.func.id})
    return {
        "pass": len(findings) == 0,
        "finding_count": len(findings),
        "findings": findings,
        "policy": "No network imports, subprocess, dynamic code execution, or host mutation helpers."
    }
