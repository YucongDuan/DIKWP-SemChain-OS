from __future__ import annotations
import argparse
import json
from pathlib import Path
from .ledger import SemanticLedger, verify_blocks
from .reports import summarize_blocks, recommendations_markdown
from .vc import export_semantic_credentials
from .static_audit import audit_source


def build_demo(claims_path: str, out: str) -> None:
    outp = Path(out)
    outp.mkdir(parents=True, exist_ok=True)
    claims = json.loads(Path(claims_path).read_text(encoding="utf-8"))
    items = claims.get("items", claims if isinstance(claims, list) else [])
    ledger = SemanticLedger()
    ledger.append_many(items, collapse=True)
    ledger_path = outp / "semantic_chain_ledger.jsonl"
    ledger.save_jsonl(ledger_path)
    blocks = SemanticLedger.load_jsonl(ledger_path)
    verify_report = verify_blocks(blocks)
    summary = summarize_blocks(blocks, verify_report)
    creds = export_semantic_credentials(blocks)
    (outp / "semantic_chain_report.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    (outp / "semantic_block_cards.json").write_text(json.dumps(blocks, ensure_ascii=False, indent=2), encoding="utf-8")
    (outp / "merkle_anchor.json").write_text(json.dumps({"chain_tip": verify_report["chain_tip"], "block_count": len(blocks), "anchor_type": "local_prototype"}, ensure_ascii=False, indent=2), encoding="utf-8")
    (outp / "verifiable_semantic_credentials.json").write_text(json.dumps(creds, ensure_ascii=False, indent=2), encoding="utf-8")
    (outp / "semantic_chain_recommendations.md").write_text(recommendations_markdown(summary), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


def verify_cmd(path: str) -> None:
    blocks = SemanticLedger.load_jsonl(path)
    print(json.dumps(verify_blocks(blocks), ensure_ascii=False, indent=2))


def static_audit_cmd(path: str, out: str | None) -> None:
    report = audit_source(path)
    if out:
        Path(out).parent.mkdir(parents=True, exist_ok=True)
        Path(out).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(prog="semchain")
    sub = parser.add_subparsers(dest="cmd", required=True)
    p_demo = sub.add_parser("build-demo")
    p_demo.add_argument("--claims", required=True)
    p_demo.add_argument("--out", required=True)
    p_verify = sub.add_parser("verify")
    p_verify.add_argument("path")
    p_audit = sub.add_parser("static-audit")
    p_audit.add_argument("path")
    p_audit.add_argument("--out")
    args = parser.parse_args()
    if args.cmd == "build-demo":
        build_demo(args.claims, args.out)
    elif args.cmd == "verify":
        verify_cmd(args.path)
    elif args.cmd == "static-audit":
        static_audit_cmd(args.path, args.out)

if __name__ == "__main__":
    main()
