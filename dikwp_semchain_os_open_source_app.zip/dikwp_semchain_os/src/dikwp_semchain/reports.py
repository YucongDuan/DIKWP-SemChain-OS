from __future__ import annotations
from typing import Any, Dict, List
from collections import Counter


def summarize_blocks(blocks: List[Dict[str, Any]], verify_report: Dict[str, Any]) -> Dict[str, Any]:
    reliability = Counter()
    types = Counter()
    blocked = 0
    review = 0
    allow = 0
    for b in blocks:
        r = b.get("dikwp", {}).get("R", {}).get("reliability", "Unknown")
        reliability[r] += 1
        types[b.get("semantic_type", "unknown")] += 1
        if r in {"Blocked", "Hollow"}:
            blocked += 1
        elif r in {"Provisional", "Contested"}:
            review += 1
        else:
            allow += 1
    score = 0.0 if not blocks else (allow + 0.5 * review) / len(blocks)
    return {
        "system": "DIKWP SemChain OS",
        "version": "0.1.0",
        "block_count": len(blocks),
        "verification_pass": verify_report.get("pass"),
        "chain_tip": verify_report.get("chain_tip"),
        "semantic_trust_score": round(score, 4),
        "decision_summary": {"allow": allow, "review": review, "block": blocked},
        "reliability_counts": dict(reliability),
        "semantic_type_counts": dict(types),
        "recommendation": "Use as a semantic evidence ledger; production deployments should add hardware-backed keys, trusted timestamps, access control, and external anchoring."
    }


def recommendations_markdown(summary: Dict[str, Any]) -> str:
    return f"""# DIKWP SemChain Recommendations

- Verification pass: `{summary.get('verification_pass')}`
- Semantic trust score: `{summary.get('semantic_trust_score')}`
- Blocks: `{summary.get('block_count')}`

## Recommended next steps

1. Keep semantic blocks append-only; never edit old blocks directly.
2. Replace demo HMAC proof with production signing using organization keys.
3. Anchor Merkle roots to a permissioned ledger, trusted timestamp service, or notarized storage.
4. Connect ProofLedger for claim-source alignment and AgentTrace for runtime events.
5. Define industry-specific P-layer intent contracts before allowing any high-impact action.
6. Treat VC-like exports as prototype credentials until a production VC implementation is integrated.
"""
