from __future__ import annotations
from typing import Any, Dict, List
from .models import DIKWPRecord
from .text_utils import keyword_hits, CERTAINTY_WORDS, SENSITIVE_WORDS


def build_dikwp_record(item: Dict[str, Any]) -> DIKWPRecord:
    claim = item.get("claim", "")
    purpose = item.get("purpose", "unspecified local purpose")
    evidence = item.get("evidence", [])
    risk = item.get("risk", [])
    constraints = item.get("constraints", [])
    certainty_hits = keyword_hits(claim, CERTAINTY_WORDS)
    sensitive_hits = keyword_hits(claim, SENSITIVE_WORDS)
    reliability = item.get("reliability", "Provisional")
    if certainty_hits and not evidence:
        reliability = "Hollow"
    if sensitive_hits:
        reliability = "Blocked"
    return DIKWPRecord(
        D=[claim] + [str(e.get("text", e)) for e in evidence[:3]],
        I=[f"subject={item.get('subject_id', 'unknown')}", f"semantic_type={item.get('semantic_type', 'claim')}", f"source_count={len(evidence)}"],
        K=item.get("knowledge", ["registered as a DIKWP semantic block"]),
        W=list(risk) + list(constraints) + (["unsupported certainty requires downgrade"] if certainty_hits else []) + (["sensitive secret-like material must not be published"] if sensitive_hits else []),
        P=[purpose, f"time_scope={item.get('time_scope', 'not specified')}", f"feedback={item.get('feedback', 'human review or ledger verification')}"] ,
        R={
            "reliability": reliability,
            "borrowed_reliability": item.get("borrowed_reliability", True),
            "residual": item.get("residual", "External verification and human review may still be required."),
            "kill_conditions": item.get("kill_conditions", ["evidence refuted", "source unsupported", "scope exceeded", "signature invalid"]),
            "certainty_hits": certainty_hits,
            "sensitive_hits": sensitive_hits,
        }
    )


def collapse_claims(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """De-falsify/de-redundancy-lite: group duplicate normalized claims and retain first with duplicate refs."""
    seen: Dict[str, Dict[str, Any]] = {}
    out: List[Dict[str, Any]] = []
    for item in items:
        key = " ".join(item.get("claim", "").lower().split())
        if key in seen:
            seen[key].setdefault("duplicate_items", []).append(item.get("id", "unknown"))
            continue
        item = dict(item)
        item.setdefault("duplicate_items", [])
        seen[key] = item
        out.append(item)
    return out
