from __future__ import annotations
from typing import List
from .canonical import sha256_hex


def merkle_root(hashes: List[str]) -> str:
    if not hashes:
        return sha256_hex("")
    level = list(hashes)
    while len(level) > 1:
        if len(level) % 2 == 1:
            level.append(level[-1])
        level = [sha256_hex(level[i] + level[i + 1]) for i in range(0, len(level), 2)]
    return level[0]
