from __future__ import annotations
from datetime import datetime, timezone
from typing import Any, Dict, List
from .canonical import hmac_sha256_hex, canonical_json


def export_semantic_credentials(blocks: List[Dict[str, Any]], issuer: str = "did:example:dikwp-semchain", secret: str = "dikwp-semchain-local-demo-secret") -> List[Dict[str, Any]]:
    """Create W3C-VC-like semantic credentials. This is a prototype export, not a formal VC implementation."""
    now = datetime.now(timezone.utc).isoformat()
    credentials = []
    for b in blocks:
        subject = {
            "id": f"urn:semchain:block:{b['block_hash']}",
            "subjectId": b.get("subject_id"),
            "claim": b.get("claim"),
            "dikwp": b.get("dikwp"),
            "merkleRoot": b.get("merkle_root"),
            "chainTipDependency": b.get("previous_hash"),
        }
        proof_material = canonical_json(subject)
        credentials.append({
            "@context": ["https://www.w3.org/ns/credentials/v2", "https://schema.org"],
            "type": ["VerifiableCredential", "DIKWPSemanticCredential"],
            "issuer": issuer,
            "validFrom": now,
            "credentialSubject": subject,
            "proof": {
                "type": "HmacSha256ProofPrototype",
                "created": now,
                "proofPurpose": "assertionMethod",
                "verificationMethod": issuer + "#local-hmac-demo-key",
                "proofValue": hmac_sha256_hex(secret, proof_material),
                "prototypeBoundary": "Not a production cryptographic VC proof. Replace with JOSE/COSE/LinkedDataProof in production."
            }
        })
    return credentials
