from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class DIKWPRecord:
    D: List[str] = field(default_factory=list)
    I: List[str] = field(default_factory=list)
    K: List[str] = field(default_factory=list)
    W: List[str] = field(default_factory=list)
    P: List[str] = field(default_factory=list)
    R: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class SemanticBlock:
    index: int
    timestamp_utc: str
    subject_id: str
    block_type: str
    semantic_type: str
    claim: str
    evidence_refs: List[Dict[str, Any]]
    payload: Dict[str, Any]
    dikwp: Dict[str, Any]
    previous_hash: str
    merkle_root: str
    block_hash: str
    signature: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
