from __future__ import annotations
import json
from .ledger import SemanticLedger, verify_blocks
from .reports import summarize_blocks


def main() -> None:
    import streamlit as st
    st.set_page_config(page_title="DIKWP SemChain OS", layout="wide")
    st.title("DIKWP SemChain OS")
    st.caption("Local-first semantic blockchain and DIKWP evidence ledger")
    uploaded = st.file_uploader("Upload semantic claims JSON", type=["json"])
    if uploaded:
        claims = json.loads(uploaded.read().decode("utf-8"))
        items = claims.get("items", claims if isinstance(claims, list) else [])
        ledger = SemanticLedger()
        ledger.append_many(items)
        blocks = [b.to_dict() for b in ledger.blocks]
        report = summarize_blocks(blocks, verify_blocks(blocks))
        st.json(report)
        st.download_button("Download ledger JSONL", ledger.to_jsonl(), file_name="semantic_chain_ledger.jsonl")

if __name__ == "__main__":
    main()
