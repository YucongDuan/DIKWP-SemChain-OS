# Code of Conduct

Be precise, evidence-oriented, and respectful. Do not use the project to deceive, harass, or bypass governance boundaries.
