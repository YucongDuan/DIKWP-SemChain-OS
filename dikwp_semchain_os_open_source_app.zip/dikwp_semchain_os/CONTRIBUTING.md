# Contributing

Contributions should preserve the governance boundary: no cryptocurrency pump mechanics, no credential forgery, no evasion tooling, and no automated high-impact enforcement decisions.
